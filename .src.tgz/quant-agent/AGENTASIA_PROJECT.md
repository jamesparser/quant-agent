# AgentAsia / devs.new project identity

This is the canonical Node0 Data Systems AgentAsia working tree.

- Local path: `/Users/terminal/Developer/projects/node0/repos-backup/devs`
- Repository: Node0 `devs` fork
- Branch: `agentasia-milestone`
- Domain marker: `devs.new`
- AgentAsia slogan: `AI that speaks your language`
- Free tier: browser-only WebGPU; users do not donate GPUs automatically
- Modes: Chat, Code, Agent
- Future: server-side accounts, heartbeat, scheduled tasks, BYOK, hosted routing
- Current priority: finish AgentAsia core and hosted Freemium modes before Lillypad/n0-token work
- Language policy: every language routes to a plan-resolved NVIDIA Nemotron model on Nebius Token Factory. The old `freemium-language` lane was never provisioned (the alias 404s at the gateway) and the config that named it has been deleted; extended languages are not a separate route
- Do not continue feature work in `/Users/terminal/agentasia/agentasia-chat`; that is the separate LobeHub-derived checkout.
- Lillypad/Bonsai Ternary v7/DSpark/vision remains deferred to the n0-token phase.
