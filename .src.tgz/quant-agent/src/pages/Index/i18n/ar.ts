import { en } from './en'

type I18n = Record<(typeof en)[number], string>

export const ar: I18n = {
  'Hey {productName}': 'Hey {productName}',
  'Your AI team is ready': 'فريق الذكاء الاصطناعي الخاص بك جاهز',
  'Failed to get response from LLM. Please try again later.':
    'فشل الحصول على رد من LLM. يرجى المحاولة مرة أخرى لاحقاً.',

  // Agent themes
  Writing: 'الكتابة',
  Learn: 'التعلم',
  Life: 'الحياة',
  Art: 'الفن',
  Coding: 'البرمجة',

  // Prompt modes & CTA
  Live: 'مباشر',
  Studio: 'استوديو',

  // PWA Install
  'Install {productName}': 'تثبيت {productName}',
  'Install this app on your device for a better experience and offline access.':
    'ثبت هذا التطبيق على جهازك للحصول على تجربة أفضل والوصول دون اتصال.',

  // Recent Activity
  'Recent conversations': 'المحادثات الأخيرة',
  'View all': 'عرض الكل',
  'Untitled conversation': 'محادثة بدون عنوان',
} as const
