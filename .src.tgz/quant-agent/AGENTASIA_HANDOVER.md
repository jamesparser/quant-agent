# AgentAsia — Handover to Mimo

**PRIVATE. Never copy this file to the public jamesparser repo.** It names servers and internal workflow. It contains no keys; keys live only in the gateway's environment on the VPS.

Written 2026-10-05 by Claude (Cowork session) for Casey's other agent, Mimo, who finishes the Nebius × NVIDIA × Tavily hackathon submission. Casey (node0datasystems@gmail.com, Phnom Penh) owns the project. Claude's subscription ends today, so Mimo is the only agent from here.

---

## 1. Where things are

| What | Where |
|---|---|
| Live site | https://agentasia.vercel.app (hard refresh after each deploy; build takes ~4 min) |
| Private repo (source of truth) | github.com/node0datasystems-lgtm/agentasia-app, branch `hackathon-nebius-2026`. Vercel builds from this. |
| Public repo (hackathon submission copy) | github.com/jamesparser/agentasia, branches `main` and `hackathon-nebius-2026`. Redacted. |
| Gateway API | https://agentasia-gateway.realcryptocap.com (Cloudflare tunnel → VPS) |
| Mac working copy | `/Users/terminal/Developer/projects/node0/repos-backup/devs` (remotes: `agentasia-app` private, `jamesparser` public, `node0-suspended` deprecated, ignore) |
| VPS | ssh alias `vps-battlechan` (key auth from Casey's Mac). Gateway code at `/opt/agentasia-gateway`, systemd unit `agentasia-gateway.service`, listens on 127.0.0.1:8787. Tunnel units: `agentasia-tunnel-durable.service` (named tunnel) and `agentasia-tunnel.service` (quick tunnel). |

Project docs in the repo: `docs/ARCHITECTURE.md`, `DECISIONS.md`, `PRICING.md`, `SUBMISSION.md` (draft submission copy), `TODO.md`, `AGENTASIA_PROJECT.md`. `server/README-auth.md` covers login.

Stack: Vite + React + TypeScript (a fork of the DEVS app), HeroUI, react-router with `/:lang` prefixes, Yjs for sync, Firebase auth (Google + email), Node gateway in `server/`.

## 2. Standing rules from Casey (do not break)

1. **Private repo first.** All code goes to the node0 private repo. The public jamesparser copy is only for submission and must have private info redacted.
2. **Private commits must be authored `node0datasystems-lgtm <node0datasystems@gmail.com>`**, otherwise Vercel will not build them. Public commits are authored `Jason Parser <jamesparser@users.noreply.github.com>`.
3. **Never force-push the public repo again** without asking. It was squashed once (with Casey's approval) to remove the original upstream author and internal notes. From now on add a normal commit on top.
4. **Never put in the public repo:** `AGENTASIA_PROJECT.md`, `docs/TODO.md`, this handover, any key, token, email address, or Phnom Penh / local path references. Scan before every public push (see section 5).
5. **All TTS voices male**, in every language, best effort. English uses Kokoro `am_adam`. Device voices expose no gender, so other languages use name heuristics (`src/lib/voice/useSpeakAloud.ts`).
6. **Free beta until Dec 25** with login; free tier is 25 requests/day. Paid tiers (Pro $20, Business $100, Enterprise $200) come after the hackathon.
7. **Mobile first.** Casey installs it to an Android home screen (Samsung S24 size, nearly square window). Desktop only needs to not break.
8. **Complete translations** (about 25 locales). The French tagline shows an `L&#39;IA` HTML-entity bug that is still unfixed.
9. Casey prefers complete files over partial edits and dislikes nano.

## 3. What the product is now

Two modes, switched by a **Chat / Worker slider pinned bottom-centre on every app screen** (desktop and phone):

- **Chat** (`/live`, `src/features/live/pages/LivePage.tsx`): a talking naga avatar, a speech line (waveform), a mic button and a replay button. Speech in uses AssemblyAI through the gateway (default), speech out uses Kokoro male voice for English and device voices elsewhere. While Kokoro's ~90 MB model downloads on first use, replies are read with the device voice so it is never silent.
- **Worker** (home `/`, `/tasks`, `/agents`, `/inbox`): agents run jobs, scheduled tasks, MCP connectors, skills.

Chat's top menu (`pageMenuActions` in LivePage): Search, History, New Task, one Settings gear (opens the **main Settings**), agent selector, then the shared page menu. **There is only one settings menu now.** Voice settings (speech input/output provider, auto-speak, AI voice) are a **Voice section inside main Settings** (`src/pages/Settings/components/VoiceSection.tsx`).

**Log in / Log out** is a text button (filled "Log in", outlined "Log out"; other languages use the existing "Sign in"/"Sign out" strings). It lives in the page-menu bar on Chat and similar pages (`src/components/PageMenu.tsx`) and as a full-width button in the Worker sidebar and mobile drawer (`src/pages/Workspace/components/Sidebar.tsx`). Component: `src/components/AccountButton.tsx`. It renders nothing when auth is not configured (so it does not show on a local dev server).

Layout plumbing worth knowing: CSS variable `--mobile-bar` (3.75rem when the bottom bar shows) is set by `MobileModeSwitch` in `src/components/ModeSwitch.tsx` and subtracted from page heights (`h-[calc(100dvh-var(--mobile-bar))]`). The Chat page is built to fit one phone screen with no scrolling. `.grid-workspace` in `globals.css` uses `minmax(0,1fr)` so lists never push past the phone edge. Phone-only sizing (bigger text, 44px touch targets) is in the "phone layer" of `src/styles/globals.css`.

## 4. The gateway (server/)

Node service, code in `server/src/`. Key routes: `POST /v1/chat/completions` (Nemotron via Nebius Token Factory, with a Tavily tool loop in `agent-loop.mjs`), `POST /v1/search` (Tavily), `POST /v1/speech/transcribe` (AssemblyAI), `POST /v1/mcp/relay`, `/v1/schedules*`, `POST /v1/facemode/session`, `GET /healthz`. Admin routes need `GATEWAY_ADMIN_TOKEN`.

Environment variable **names** on the VPS (values stay there, never in git): `NEBIUS_API_KEY`, `TAVILY_API_KEY`, `ASSEMBLYAI_API_KEY`, `RESEND_API_KEY`, `GATEWAY_ADMIN_TOKEN`, `FIREBASE_PROJECT_ID`, spend guards (`SPEND_GUARD_ENABLED`, `DAILY_SPEND_CAP_USD`, `TOTAL_SPEND_CAP_USD`), `SCHEDULER_ENABLED`, alert email vars, and FaceMode/LiveKit vars (`FACEMODE_*`, `LIVEKIT_*`).

Deploying gateway changes: edit on the VPS in `/opt/agentasia-gateway` (it is not a git checkout), then `systemctl restart agentasia-gateway`. Check `GET /healthz`. Keep `server/` in the repo in sync with what runs there.

Metering: guests get 25 requests/day per IP (chat and speech both count; Claude's testing exhausted the Mac's IP). Signed-in users are metered by plan. Cloudflare blocks the default Python user-agent, so use a browser UA for curl from scripts.

## 5. Shipping code (the exact method that works)

Work in the Mac checkout. Local commits use `-c user.name='Jason Parser' -c user.email=jamesparser@users.noreply.github.com`. Commit only your own files (`git add <paths>`); the working tree contains **uncommitted work from another agent** (`package.json`, `server/.env.example`, `server/src/index.mjs`, `server/src/facemode.mjs`, `src/features/live/FaceModeNaga.tsx`). Do not commit or discard that unless Casey says FaceMode is wanted. It needs the `livekit-client` package, which is not installed, so `tsc` always shows 3 errors in `FaceModeNaga.tsx`. Those are the only expected type errors.

**Private push** (keeps the node0 author Vercel requires):

```
git fetch agentasia-app
git worktree add -B tmp-private /Users/terminal/ws-priv agentasia-app/hackathon-nebius-2026
cd /Users/terminal/ws-priv
git cherry-pick -x <your-local-commit>
git -c user.name=node0datasystems-lgtm -c user.email=node0datasystems@gmail.com commit --amend --no-edit --reset-author
git push agentasia-app tmp-private:hackathon-nebius-2026
cd - && git worktree remove --force /Users/terminal/ws-priv && git branch -D tmp-private
```

**Public push** (additive commit of the redacted tree, no force):

```
git fetch jamesparser
export GIT_INDEX_FILE=/tmp/pubidx; rm -f $GIT_INDEX_FILE
git read-tree agentasia-app/hackathon-nebius-2026
git rm --cached -f AGENTASIA_PROJECT.md docs/TODO.md AGENTASIA_HANDOVER.md
git grep --cached -n -i -E 'casey|node0datasystems|phnom|/Users/terminal|ghp_|github_pat_|sk-[A-Za-z0-9]{20}|AIza'   # review hits; test fixtures and the gateway hostname are fine
T=$(git write-tree); unset GIT_INDEX_FILE
# commit as Jason Parser with GIT_AUTHOR_*/GIT_COMMITTER_* env vars, parent = jamesparser/main
C=$(echo 'message' | git commit-tree $T -p jamesparser/main)
export JP_TOKEN=$(gh auth token --user jamesparser)
git -c credential.helper= -c 'credential.helper=!f() { echo username=jamesparser; echo password=$JP_TOKEN; }; f' push jamesparser $C:refs/heads/main $C:refs/heads/hackathon-nebius-2026
gh auth switch -u node0datasystems-lgtm
```

`gh` has both accounts logged in. Always switch back to `node0datasystems-lgtm` after the public push. `~/ship-agentasia.sh` is the old all-in-one script; it replays public → private and is no longer the right path, so use the manual steps above.

Before pushing run `npx tsc --noEmit -p .` (takes 30–60 s; run it with `nohup` and poll).

## 6. Tooling gotchas (these cost real time)

- Claude worked through an `osascript` `do shell script` bridge to the Mac. Quoting is brittle: escaped pipes and backslashes inside the AppleScript string break parsing. The reliable pattern was to write a Python patch script, base64-encode it, and run `echo <b64> | base64 -d | python3` in the repo. If you have normal shell access, ignore this.
- `pkill -f 'vite --port 5199'` inside the same command line can match and kill its own shell. Kill by PID in a separate call.
- Local preview: `NODE_OPTIONS=--max-old-space-size=6144 npx vite --port 5199 --host 127.0.0.1`. Auth is not configured locally, so the Log in buttons are hidden there. The browser pane's phone emulation: 375×812.
- Measure layout with `getBoundingClientRect` rather than trusting screenshots; a first-run language-wheel overlay can blank them.
- The sandbox Claude ran in could not reach the gateway; calls had to go through the Mac.

## 7. Tavily — needs Casey's attention before judging

The gateway does call Tavily, and a live test search returned a real answer. But the key on the server (ends in `…753X`) is on the **Researcher plan and shows 11 of 1,000 credits used**, while Casey's own dashboard (node0datasystems@gmail.com) shows 0 of 1,000. So the server key almost certainly belongs to a different Tavily login. Ask Casey to check the API-keys page for that key; if it isn't there, he creates a key on his account and you put it in the gateway env (`TAVILY_API_KEY`) and restart the service. The hackathon bonus for using Tavily may depend on the account, so settle this early. The gateway also caps shared searches at `TAVILY_GLOBAL_DAILY` (default 30/day, about 900/month); raise it only once the right account is confirmed.

## 8. Known issues and unverified items

- **Audible male voice on a real phone is untested.** Kokoro wasm q8 speed on phones is unmeasured; the first-use download is ~90 MB and is not cached across visits as far as verified. Device-voice fallback is in place.
- **The naga image** has a hard dark disc and faint stock-photo watermark text baked into the file. Replace it with a clean asset if one exists.
- **Meta MMS voices** are non-commercial licensed. Replace before charging anyone.
- Draft locales have not been reviewed by native speakers. Male voices outside English are best-effort.
- Sync between devices, MCP relay with a signed-in token, and the Privacy/Open Source pages' inherited text are unverified.
- Page title briefly shows "Not Found" during load (cosmetic).
- Settings "Voice" section: label exists in all locales, but the panel's inner strings were only checked in English.
- FaceMode (premium avatar via LiveKit) is another agent's unfinished work; skip unless Casey asks.
- `docs/SUBMISSION.md` is **draft copy and partly stale** (it still describes on-device Parakeet ASR as the main speech input). Today speech in is AssemblyAI cloud via the gateway by default, with browser/device dictation as alternates, and English voice is Kokoro. Rewrite those claims to match what ships before submitting. It also says "do not submit until [pending] items are real."

## 9. Suggested order for finishing the hackathon

1. Confirm the Tavily key/account with Casey (section 7). Do a live check that a question needing current facts triggers a search and shows citations.
2. Smoke-test the live site on a phone-size window and a desktop window: Chat (mic, reply, replay, voice), Worker (new task, tasks list, agents list), Settings (including the Voice section), Log in / Log out, language switch.
3. Reconcile `docs/SUBMISSION.md` and the README with what actually ships; remove or label anything not built.
4. Make sure the public jamesparser repo has the final redacted tree (section 5), README renders, and no private strings.
5. Confirm the submission deadline and required format on the hackathon page (not recorded in the repo) and submit.
6. After the hackathon: replace MMS voices, native-review the locales, wire billing (Stripe, NOWPayments) per `docs/PRICING.md`.

## 10. Last known state (2026-10-05)

- Private head: `9697172c` ("Phone: fix Tasks/Agents lists running off the right edge; Log in button in Worker sidebar; top menu spacing").
- Public head: `964d1509` (same tree minus the internal files). Two public commits share a message because one push was repeated after an error; the code is identical.
- Gateway healthy (`/healthz` ok), search and chat working.
- Vite dev server stopped; no worktrees left open.
